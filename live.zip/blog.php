<?php
// Include the database connection file
include("connection.php");

// Check if an article ID is provided in the URL
if (isset($_GET['id'])) {
    // Sanitize the article ID
    $article_id = intval($_GET['id']);

    // Fetch the article from the database
    $sql = "SELECT * FROM tiger WHERE id = $article_id";
    $result = mysqli_query($conn, $sql);

    // Check if the article exists
    if (mysqli_num_rows($result) > 0) {
        $article = mysqli_fetch_assoc($result);
    } else {
        echo "Article not found!";
        exit();
    }
} else {
    echo "Invalid article ID!";
    exit();
}

// Close the database connection
mysqli_close($conn);
?>

<?php
include("top.php");
?>
    <title><?php echo htmlspecialchars($article['title']); ?> - Full Article</title>
    <!-- Flowbite and Tailwind CSS -->
    <link href="https://cdn.jsdelivr.net/npm/flowbite/dist/flowbite.min.css" rel="stylesheet" />
    <style>
        .bg{
            background:#dbd8e3;
            border-radius:8px;
            padding:10px;
            text-transform:capitalize;
            margin-bottom:20px;
        }
        .center{
            margin:10px;
            display:flex;
            justify-content:center;
            margin-bottom:20px;
        }
        </style>
</head>
<body class="bg-gray-100 text-gray-900">

<?php
include("nav.php");
?>

<div class="max-w-4xl mx-auto p-6 bg-white shadow-lg rounded-lg mt-12">
    <!-- Article Title -->
     <div class="bg">
    <h1 class="text-3xl font-bold text-gray-800 mb-4" ><?php echo htmlspecialchars($article['title']); ?></h1>
    
    <!-- Article Category -->
    <div class="text-lg text-purple-600 mb-6"><strong>Category:</strong> <?php echo htmlspecialchars($article['category']); ?></div>
    </div>

<div class="center">
    <figure class="max-w-lg">
  <img class="h-auto max-w-full rounded-lg" src="<?php echo htmlspecialchars($article['image_path']); ?>" alt="image description">
  
</figure>
</div>


    <!-- Article Content -->
    <div class="text-lg text-gray-700 leading-relaxed mb-6">
        <?php echo nl2br($article['content']); ?>
    </div>

    <!-- Article Published Date -->
    <div class="text-sm text-gray-500 mt-4"><strong>Published on:</strong> <?php echo htmlspecialchars($article['created_at']); ?></div>
</div>
<br><br><br>

<!-- Flowbite JS -->
<script src="https://cdn.jsdelivr.net/npm/flowbite/dist/flowbite.min.js"></script>

<?php
include("footer.php");
?>
<?php
include("down.php");
?>
